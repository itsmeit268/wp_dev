<?php
/** Don't load directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'Ruby_GTM_Integration' ) ) {
	include_once FOXIZ_CORE_PATH . 'lib/simple-gtm-ga4/simple-gtm-ga4.php';
}
if ( ! class_exists( 'Foxiz_Post_Elements' ) ) {
	include_once FOXIZ_CORE_PATH . 'lib/foxiz-elements/foxiz-elements.php';
}
if ( ! class_exists( 'RB_OPENAI_ASSISTANT' ) ) {
	include_once FOXIZ_CORE_PATH . 'lib/ruby-openai/ruby-openai.php';
}
include_once FOXIZ_CORE_PATH . 'define.php';
include_once FOXIZ_CORE_PATH . 'lib/bbp/ruby-bbp-supported.php';
include_once FOXIZ_CORE_PATH . 'admin/core-helpers.php';
include_once FOXIZ_CORE_PATH . 'admin/taxonomy.php';
include_once FOXIZ_CORE_PATH . 'admin/sub-pages.php';
include_once FOXIZ_CORE_PATH . 'admin/import/ajax.php';
include_once FOXIZ_CORE_PATH . 'admin/core.php';
include_once FOXIZ_CORE_PATH . 'admin/rb-meta/rb-meta.php';
include_once FOXIZ_CORE_PATH . 'admin/fonts/init.php';
include_once FOXIZ_CORE_PATH . 'admin/info.php';
include_once FOXIZ_CORE_PATH . 'admin/upgrade.php';
include_once FOXIZ_CORE_PATH . 'podcast/init.php';

include_once FOXIZ_CORE_PATH . 'includes/helpers.php';
include_once FOXIZ_CORE_PATH . 'elementor/base.php';
include_once FOXIZ_CORE_PATH . 'includes/actions.php';
include_once FOXIZ_CORE_PATH . 'includes/optimized.php';
include_once FOXIZ_CORE_PATH . 'includes/login-screen.php';
include_once FOXIZ_CORE_PATH . 'includes/svg.php';
include_once FOXIZ_CORE_PATH . 'includes/table-contents.php';
include_once FOXIZ_CORE_PATH . 'includes/video-thumb.php';
include_once FOXIZ_CORE_PATH . 'includes/extras.php';
include_once FOXIZ_CORE_PATH . 'includes/shortcodes.php';
include_once FOXIZ_CORE_PATH . 'includes/amp.php';
include_once FOXIZ_CORE_PATH . 'includes/personalize-helper.php';

include_once FOXIZ_CORE_PATH . 'membership/membership.php';
include_once FOXIZ_CORE_PATH . 'membership/options.php';
include_once FOXIZ_CORE_PATH . 'e-template/init.php';
include_once FOXIZ_CORE_PATH . 'includes/shares.php';
include_once FOXIZ_CORE_PATH . 'includes/ads.php';
include_once FOXIZ_CORE_PATH . 'reaction/reaction.php';

include_once FOXIZ_CORE_PATH . 'includes/widget.php';
include_once FOXIZ_CORE_PATH . 'widgets/fw-instagram.php';
include_once FOXIZ_CORE_PATH . 'widgets/fw-mc.php';
include_once FOXIZ_CORE_PATH . 'widgets/banner.php';
include_once FOXIZ_CORE_PATH . 'widgets/sb-post.php';
include_once FOXIZ_CORE_PATH . 'widgets/sb-follower.php';
include_once FOXIZ_CORE_PATH . 'widgets/sb-weather.php';
include_once FOXIZ_CORE_PATH . 'widgets/sb-social-icon.php';
include_once FOXIZ_CORE_PATH . 'widgets/sb-youtube.php';
include_once FOXIZ_CORE_PATH . 'widgets/sb-flickr.php';
include_once FOXIZ_CORE_PATH . 'widgets/sb-address.php';
include_once FOXIZ_CORE_PATH . 'widgets/sb-instagram.php';
include_once FOXIZ_CORE_PATH . 'widgets/sb-ad-image.php';
include_once FOXIZ_CORE_PATH . 'widgets/sb-ad-script.php';
include_once FOXIZ_CORE_PATH . 'widgets/sb-facebook.php';
include_once FOXIZ_CORE_PATH . 'widgets/ruby-template.php';