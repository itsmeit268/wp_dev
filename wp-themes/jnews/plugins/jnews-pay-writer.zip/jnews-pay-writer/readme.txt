Change Logs :

== 11.0.1 ==
- [BUG] Fix Undefined index view in Post Eartning Status
- [BUG] Fix Enable fix amount donation option issue
- [IMPROVEMENT] Change The Maunal Pay button to Mark As Paid

== 11.0.0 ==
- [IMPROVEMENT] Compatible with JNews v11.0.0

== 10.0.5 ==
- [BUG] Fix customizer issue with pay writer and view counter

== 10.0.4 ==
- [IMPROVEMENT] Support pay writer Arab word count
- [IMPROVEMENT] Update payment option on customizer

== 10.0.3 ==
- [BUG] Fix error warning

== 10.0.2 ==
- [BUG] Fix paypal account validation not working

== 10.0.1 ==
- [BUG] Fix missing translation
- [BUG] Fix Pay Writer section on RTL mode

== 10.0.0 ==
- First Release