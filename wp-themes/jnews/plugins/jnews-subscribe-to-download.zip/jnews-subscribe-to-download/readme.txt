Change Log :

== 11.0.0 ==
- [IMPROVEMENT] Compatible with JNews v11.0.0

== 10.0.1 ==
- [BUG] Fix element option not rendered in Elementor

== 10.0.0 ==
- [IMPROVEMENT] Compatible with JNews v10.0.0

== 9.0.0 ==
- [IMPROVEMENT] Compatible with JNews v9.0.0

== 8.0.0 ==
- [IMPROVEMENT] Compatible with JNews v8.0.0

== 7.0.1 ==
- [IMPROVEMENT] Add placeholder field option
- [IMPROVEMENT] Add frontend translation for subscription success

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.1 ==
- [BUG] Fix class not found issue

== 6.0.0 ==
- First Release
