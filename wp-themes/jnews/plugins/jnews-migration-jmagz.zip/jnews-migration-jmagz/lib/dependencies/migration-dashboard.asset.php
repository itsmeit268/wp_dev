<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-hooks', 'wp-i18n', 'wp-polyfill'), 'version' => 'dcaeafca4396545af1d9');
