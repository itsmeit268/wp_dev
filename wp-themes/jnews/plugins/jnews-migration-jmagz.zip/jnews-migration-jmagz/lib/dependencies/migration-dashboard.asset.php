<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-hooks', 'wp-i18n', 'wp-polyfill'), 'version' => '3ffc0fd9a8e0533f9bcf');
