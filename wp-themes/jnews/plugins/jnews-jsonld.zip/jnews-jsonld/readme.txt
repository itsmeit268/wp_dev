Change Log :

== 11.0.3 ==
- [BUG] Add Timezone in datePublished, dateModified and dateCreated fields in Article JSON Schema

== 11.0.2 ==
- [BUG] Fix Double Breadcrumb JSON Schema

== 11.0.1 ==
- [IMPROVEMENT] Add tiktok into user social info

== 11.0.0 ==
- [IMPROVEMENT] Compatible with JNews v11.0.0

== 10.0.4 ==
- [IMPROVEMENT] Add SKU rich snippet

== 10.0.3 ==
- [IMPROVEMENT] New in structured data (JSON LD): Pros and cons
- [BUG] Fix JSON LD warning issue

== 10.0.2 ==
- [BUG] Fix JSON LD brand

== 10.0.1 ==
- [IMPROVEMENT] Add Twitch social author

== 10.0.0 ==
- [IMPROVEMENT] Compatible with JNews v10.0.0

== 9.0.0 ==
- [IMPROVEMENT] Compatible with JNews v9.0.0

== 8.0.0 ==
- [IMPROVEMENT] Compatible with JNews v8.0.0

== 7.0.3 ==
- [BUG] Fix encoding JSON LD

== 7.0.2 ==
- [IMPROVEMENT] Update some structured data

== 7.0.1 ==
- [BUG] Fix invalid json output

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.2 ==
- [IMPROVEMENT] Update Google Structured Data

== 5.0.1 ==
- [IMPROVEMENT] Compatible with new Google Structured Data

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.0 ==
- First Release
