<?php
the_post();
the_content();
