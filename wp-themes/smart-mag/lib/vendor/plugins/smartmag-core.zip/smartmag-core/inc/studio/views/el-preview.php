<script type="text/template" id="tmpl-ts-el-studio-preview">
	
	<div class="ts-el-studio__preview">
		<img src="{{ data.item.previewSrc }}" srcset="{{ data.item.previewSrcset }}" alt="{{ data.item.title }}" />
	</div>

</script>