=== Sphere Post Views ===
Contributors: asadkn, ThemeSphere
Tags: views, post views, views counter
Requires at least: 5.5
Tested up to: 6.0
Requires PHP: 7.1
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Post views counters for ThemeSphere themes, slightly based on WP Popular Posts.

== Description ==
A post views plugin with advanced performance optimization features, for ThemeSphere themes.

== Changelog ==

= 1.0.1 =
* Fixed: WPML counters not being counted.
* Fixed: PHP 8.1 warning on type declaration.

= 1.0.0 =
* Initial release.