<?php return array('dependencies' => array(), 'version' => 'c7e951d008a9cf980ea8');
