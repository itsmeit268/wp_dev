<?php return array('dependencies' => array(), 'version' => '3b07eec2b793a860c7ba');
