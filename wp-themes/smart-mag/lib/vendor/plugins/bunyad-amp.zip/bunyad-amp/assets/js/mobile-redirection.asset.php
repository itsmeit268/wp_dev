<?php return array('dependencies' => array(), 'version' => '9f2db19f71eff82d5fd4');
