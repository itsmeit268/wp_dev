<?php return array('dependencies' => array(), 'version' => '3a7dbe299cdcf4cabfd6');
