<?php return array('dependencies' => array(), 'version' => '1f27c647b207020377e6');
