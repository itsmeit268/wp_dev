<?php return array('dependencies' => array('lodash', 'wp-i18n'), 'version' => 'a0e5e200caed2b3076b9');
