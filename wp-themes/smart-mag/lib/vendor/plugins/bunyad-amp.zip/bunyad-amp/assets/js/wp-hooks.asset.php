<?php return array('dependencies' => array(), 'version' => '77aaf1fb4de1a90a5a39');
