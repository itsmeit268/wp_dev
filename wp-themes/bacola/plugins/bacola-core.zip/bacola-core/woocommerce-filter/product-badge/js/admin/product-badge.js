(function ($) {
  "use strict";

	$(document).ready(function() {
		$('.bacola-color-field').wpColorPicker();

		$('#klb_product_badge_type-label').closest('.rwmb-field').hide();
		$('#klb_product_badge-label').closest('.rwmb-field').hide();
	});
	
}(jQuery));