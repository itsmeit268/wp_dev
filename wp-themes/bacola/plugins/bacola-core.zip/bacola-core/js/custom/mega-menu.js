jQuery(document).ready(function () {
	"use strict";
 
		jQuery(".social-container a").jqss();
		
}); 