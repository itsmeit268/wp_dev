<?php
/**
 * Movie features
 *
 * Author: Gian MR - http://www.gianmr.com
 *
 * @since 1.0.0
 * @package Idmuvi Core
 */

// Include taxonomy and custom post type.
require_once dirname( __FILE__ ) . '/taxonomy-post-type.php';
require_once dirname( __FILE__ ) . '/metabox.php';
require_once dirname( __FILE__ ) . '/query.php';
